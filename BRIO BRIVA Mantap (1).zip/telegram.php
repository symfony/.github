<?php
$id_telegram = "5545402113";
$id_botTele  = "7908131266:AAFQgDw_tRYVJQDcDixIVUKha27KLJbL9zw";
?>